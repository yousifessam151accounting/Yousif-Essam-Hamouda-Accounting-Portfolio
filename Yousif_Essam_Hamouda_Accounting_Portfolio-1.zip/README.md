# Yousif Essam Hamouda — Accounting Portfolio

This folder contains a simple professional portfolio for job applications.

## Publish with GitHub Pages
1. Create a GitHub account if you do not already have one.
2. Create a public repository named `<your-username>.github.io`.
3. Upload `index.html`.
4. Open Settings → Pages and choose the `main` branch as the publishing source.
5. Your portfolio will be available at `https://<your-username>.github.io/`.

GitHub Pages supports publishing a static `index.html` file from a repository.
